/*
 * ActividadN2.c
 *
 * Created: 20 mar. 2024 16:41:57
 * Author : Spiazzi & Velasco
 * Micro controller: Arduino UNO ATMEGA328P
 */ 

#include <avr/io.h>
#include <avr/eeprom.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <avr/common.h>
#include <stdio.h>
#include "HCSR04.h"

/************************************************************************/
/*               Type definitions (flags and unions)					*/
/************************************************************************/
typedef union{
	struct{
		uint8_t bit0: 1;
		uint8_t bit1: 1;
		uint8_t bit2: 1;
		uint8_t bit3: 1;
		uint8_t bit4: 1;
		uint8_t bit5: 1;
		uint8_t bit6: 1;
		uint8_t bit7: 1;
	}bits;
	uint8_t byte;
}_uFlags;

typedef struct __attribute__((packed, aligned(1))){
	uint8_t *buf;
	uint8_t sizeBuf;
	uint8_t iw;
	uint8_t ir;
	uint8_t timeOut;
	uint8_t header;
	uint8_t cks;
}_sRX;

typedef struct __attribute__((packed, aligned(1))){
	uint8_t *buf;
	uint8_t sizeBuf;
	uint8_t iw;
	uint8_t ir;
	uint8_t cks;
}_sTX;

typedef struct __attribute__((packed, aligned(1))){
	uint8_t index;
	uint8_t boxType;
	uint8_t actTime;
	uint8_t objTime;
}_sBox;

typedef enum{
	BOX_SIZEA,
	BOX_SIZEB,
	BOX_SIZEC,
	BOX_UNKNOWN
}_eBoxType;

/************************************************************************/
/*						    	Definitions								*/
/************************************************************************/
#define LEDSTATUS			PINB5
#define HCSR04_1_ECHO		PINB0
#define HCSR04_1_TRIG		PINB1

#define IS10MS				0
#define OFF					0
#define FALSE				0
#define ON					1
#define TRUE				1
#define SIZEA_MIN			4
#define SIZEA_MAX			6
#define SIZEB_MIN			7
#define SIZEB_MAX			9
#define SIZEC_MIN			10
#define SIZEC_MAX			12
#define SIZEBUFRX			128
#define SIZEBUFTX			128

#define boxTypeChanged		flags.bits.bit0
#define allFlags			flags.byte

// Constants
uint8_t		bufRX[SIZEBUFRX], bufTX[SIZEBUFTX];
uint8_t		aux8			= 0;
uint8_t		count50ms		= 6;
uint8_t		count100ms		= 10;
uint8_t		count1000ms		= 10;
uint16_t	lastDistance	= 0;
uint16_t	aux16			= 0;
uint32_t	hbMask			= 0x80000000;
uint32_t	heartbeat		= 0xAF000000;

uint32_t	handleHCSR04_1;
char		sizeIndicator[1];
char		strAux[32];
_sRX		rx;
_sTX		tx;

// Initialization of constants
_uFlags  flags;
_eBoxType	boxDetected = BOX_UNKNOWN, lastBoxDetected = BOX_UNKNOWN;
EEMEM uint8_t varEEPROM1;
PROGMEM const uint8_t varFlash = 10;

// Function's declarations
void iniTimer();
void iniPorts();
void IniUSART();
void every10ms();
void heartbeatTask();

void PutHeaderOnTx(_sTX *aTx, uint8_t id, uint8_t legth);
void PutByteOnTx(_sTX *aTx, uint8_t value);
void PutBufOnTx(_sTX *aTx, uint8_t *buf, uint8_t length);
void PutStrOnTx(_sTX *aTx, const char *str);
void sendDataUSART();

void WritePINHCSR04_1(uint8_t value);
void HCSR04_1_ReadyDistance(uint16_t distance);

void boxTypeTask();

// Interruptions
ISR(USART_RX_vect)
{
	rx.buf[rx.iw++] = UDR0;							// Charges data from UDR0 to Rx buffer
	rx.iw &= rx.sizeBuf;							// Sends data from buffer 
}

ISR(TIMER1_COMPA_vect)
{
	OCR1A += 20000;									// Adds 10 ms in the timer1 comparator
	GPIOR0 |= _BV(IS10MS);							// Flag that indicates that 10 ms have passed
}

ISR(TIMER1_COMPB_vect)
{
	HCSR04_TriggerReady(handleHCSR04_1);
	TIFR1 |= _BV(ICF1);								// Timer/Counter1 Output Compare A Match Flag enabled
	TCCR1B = (1 << ICNC1) | (1 << ICES1);			// Input Capture Noise Canceler and Input Capture Edge Select activated
	TCCR1B |= (1 << CS11);							// Prescaler definition (x8): CS12 = 0 and CS10 = 0
	TIMSK1 = _BV(ICIE1) | _BV(OCIE1A);				// Input Capture Interrupt and Output Compare A Match Interrupt enabled
}

ISR(TIMER1_CAPT_vect)
{
	if (TCCR1B & _BV(ICES1))						// Rising edge will trigger the capture				
	{
		TCCR1B = (1 << ICNC1) | (1 << CS11);
		HCSR04_RiseEdgeTime(handleHCSR04_1, ICR1 >> 1);
	}
	else											// Falling edge is used as trigger
	{
		TIMSK1 &= ~_BV(ICIE1);
		HCSR04_FallEdgeTime(handleHCSR04_1, ICR1 >> 1);
	}
}

void iniTimer()
{
	TCCR1A = 0;										// Operation mode of Timer1: NORMAL
	OCR1A = 20000;									// Setting limit of time counter: 10 milliseconds
	TIFR1 = TIFR1;									// Clear all bits for the timer1's interruption
	TIMSK1 = (1 << OCIE1A);							// Enables interruption of Comparator A (Timer1)
	TCCR1B = (1 << ICNC1) | (1 << CS11);			// Input Capture Noise Canceler activated, Prescaler definition (x8)
}

void iniPorts()
{
	DDRB = (1 << HCSR04_1_TRIG) | (1 << LEDSTATUS); // Sets PB1 (Trigger) and PB5 (Led) as OUTPUT ports
}

void IniUSART()
{
	UCSR0A = UCSR0A;								// All bits in UCSR0A are cleared					
	UCSR0A = (1 << U2X0);							// Doubles the transfer rate for asynchronous communication
	UCSR0B = (1 << RXCIE0) | (1 << RXEN0);			// RX Complete Interrupt and Receiver enabled
	UCSR0B = (1 << TXEN0);							// Transmitter enabled
	UCSR0C = (1 << UCSZ01) | (1 << UCSZ00);			// 8-bit character size for the Receiver and Transmitter buffers
	UBRR0 = 16;										// Sets baud rate of transmission: [UBRR0 = (16 MHz / 8*BR) - 1] (rounded)

	rx.buf = bufRX;									// Creates a local Rx buffer
	rx.sizeBuf = SIZEBUFRX-1;						// Size of Rx buffer has to be decremented by 1 (128 -> 0-127)
	rx.iw = 0;										// Writing index of Rx buffer is initialized in 0
	rx.ir = 0;										// Reading index of Rx buffer is initialized in 0
	rx.header = 0;									// Header of Rx buffer is initialized in 0
	
	tx.buf = bufTX;									// Creates a local tx buffer
	tx.sizeBuf = SIZEBUFTX-1;						// Size of Tx buffer has to be decremented by 1 (128 -> 0-127)
	tx.iw = 0;										// Writing index of Tx buffer is initialized in 0
	tx.ir = 0;										// Reading index of Tx buffer is initialized in 0
}

void every10ms()
{
	GPIOR0 &= _BV(LEDSTATUS);						// Activation of timer: 10 cycles * 10 ms = 100 ms
	count50ms--;									// 50 milliseconds counter decrements
	count100ms--;									// 100 milliseconds counter decrements
	if (!count50ms)
	{
		aux16 = TCNT1;								// Loads actual time in TCNT1 into aux16
		aux16 += 15;								// Adds 15 (us) to the previously saved time at TCNT1
		OCR1B = aux16;								// Then loads the value into OCR1B, generating an Output Compare Interrupt
		TIFR1 = _BV(OCF1B) | _BV(OCF1A);			// Flag set after the counter value in TCNT1 equals OCR1A and OCR1B
		TIMSK1 = _BV(OCIE1B) | _BV(OCIE1A);			// Timer/Counter1 Output Compare A and B Match interrupts are enabled.
		HCSR04_Start(handleHCSR04_1);				// Enables a new measure of the HCSR04
	}
	
	if (!count100ms)								// If 100 ms have passed
	{
		count100ms = 10;							// Restarts 100 ms counter
		heartbeatTask();							// Control the heartbeat sequence of the system
		if (count1000ms)							// If 1000 ms haven't passed
			count1000ms--;							// Counter decrements
	}
}

void heartbeatTask()
{
	if (heartbeat & hbMask)
		PORTB |= (1 << LEDSTATUS);					// Turn on LED
	else
		PORTB &= ~_BV(LEDSTATUS);					// Turn off LED
	
	hbMask >>= 1;									// Displace hbMask one place to the right
	if (!hbMask)
		hbMask = 0x80000000;						// If there's a 0 in that place, changes the actual positions to compare the right way
}

void PutHeaderOnTx(_sTX *aTx, uint8_t id, uint8_t legth){	
}

void PutByteOnTx(_sTX *aTx, uint8_t value){
}

void PutBufOnTx(_sTX *aTx, uint8_t *buf, uint8_t length){
}

void PutStrOnTx(_sTX *aTx, const char *str)
{
	uint8_t i = 0;
	while (str[i])									// While there is information that has not been read yet
	{
		aTx->buf[aTx->iw++] = str[i++];				// Loads data into the Tx buffer
		aTx->iw &= aTx->sizeBuf;					// Updates index in the Tx buffer
	}
}

void sendDataUSART()
{
	if (tx.ir != tx.iw)								// If Tx's reading and writing indexes are different
	{
		if (UCSR0A & _BV(UDRE0))					// If Tx buffer is empty, and ready to receive new data
		{
			UDR0 = tx.buf[tx.ir++];					// Then new data is loaded into the Tx buffer
			tx.ir &= tx.sizeBuf;					// New size of the Tx buffer is updated
		}
	}
}

void WritePINHCSR04_1(uint8_t value)
{
	if (value)
		PORTB |= _BV(HCSR04_1_TRIG);				// Sets a HIGH state (1) in the TRIGGER pin
	else
		PORTB &= ~_BV(HCSR04_1_TRIG);				// Sets a LOW state (0) in the TRIGGER pin
}

void HCSR04_1_ReadyDistance(uint16_t distance)
{
	lastDistance = distance;						// Saves last measurement in a variable
	if (!count50ms)
	{
		count50ms = 6;								// Restarts 50 ms counter
		boxTypeTask();
	}
}

void boxTypeTask()
{
	if (lastDistance >= SIZEA_MIN && lastDistance <= SIZEA_MAX)
	{
		boxDetected = BOX_SIZEA; 
		sprintf(&sizeIndicator[0], "A");
	}
	else if (lastDistance >= SIZEB_MIN && lastDistance <= SIZEB_MAX)
	{
		boxDetected = BOX_SIZEB; 
		sprintf(&sizeIndicator[0], "B");
	}
	else if (lastDistance >= SIZEC_MIN && lastDistance <= SIZEC_MAX)
	{
		boxDetected = BOX_SIZEC;
		sprintf(&sizeIndicator[0], "C");
	}
	else if (lastDistance < SIZEA_MIN || lastDistance > SIZEC_MAX)
	{
		boxDetected = BOX_UNKNOWN;
	}
	if ((lastBoxDetected != boxDetected)&&(boxDetected != BOX_UNKNOWN))
	{
		sprintf(strAux, "*** DETECTED BOX TYPE %c: %.2d cm\n", sizeIndicator[0], lastDistance);
		PutStrOnTx(&tx, strAux);					// Puts last distance into the Tx buffer
	}
	lastBoxDetected = boxDetected;
}

int main(void)
{
    cli();
	allFlags = OFF;									// Initializes flags
    iniPorts();										// Initializes ports
    iniTimer();										// Initializes timer1
    IniUSART();										// Initializes USART
	// Configures the sensor's handle, setting HIGH the trigger pin for 16 us
    handleHCSR04_1 = HCSR04_AddNew(WritePINHCSR04_1, 16);
	// Configures the sensor' state, setting it ready to take a new measure
    HCSR04_AttachOnReadyMeasure(handleHCSR04_1, HCSR04_1_ReadyDistance);
    PutStrOnTx(&tx, "READY\r\n");
    sei();

	while (1) 
    {
		if (GPIOR0 & _BV(IS10MS))					// If 10 ms have passed
			every10ms();
			
		sendDataUSART();							// Does USART tasks
		HCSR04_Task();								// Does measurement tasks
	}
}