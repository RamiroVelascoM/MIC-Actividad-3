/*
 * ActividadN2.c
 *
 * Created: 20 mar. 2024 16:41:57
 * Authors:	Leiva, Spiazzi & Velasco
 * Micro controller: Arduino UNO ATMEGA328P
 */ 

#include <avr/io.h>
#include <avr/eeprom.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <avr/common.h>
#include <stdio.h>
#include <stdbool.h>
#include "UNERBUS.h"
#include <math.h>

/************************************************************************/
/*               Type definitions (flags and unions)					*/
/************************************************************************/

//---------Flags and variables---------//

typedef union{
	struct{
		uint8_t bit0: 1;
		uint8_t bit1: 1;
		uint8_t bit2: 1;
		uint8_t bit3: 1;
		uint8_t bit4: 1;
		uint8_t bit5: 1;
		uint8_t bit6: 1;
		uint8_t bit7: 1;
	}bits;
	uint8_t byte;
}_uFlags;

//------------Box activities-----------//



//---------------Tx & Rx---------------//

typedef enum{
	ACK=0x0D,
	FAIL=0x0A,
	GETALIVE=0xF0,
	GETBELTINFO=0x50,
	STOPBELT=0x51,
	BOXKICK=0x52,
	BELTRESET=0x53,
	SPEEDCHANGE=0x54,
	NEWBOX=0x5F,
	OTHERS
}_eID;

typedef struct __attribute__((packed, aligned(1))){
	uint8_t v;
	uint8_t	boxType0;
	uint16_t cmOut0;
	uint8_t boxType1;
	uint16_t cmOut1;
	uint8_t	boxType2;
	uint16_t cmOut2; // info del simulador de German
	
	uint8_t openExitType;
	uint8_t iOnBelt;
	uint8_t iLastBox;
	uint32_t ExitTimeObjectives[45];
	uint32_t ActualExitTimes[45];
	uint8_t BoxesStatus[45];
	uint8_t boxesDetectedTypes[45];
	uint8_t beltStatus; // variables propias
}_sBOX;

typedef union{
	uint8_t		u8[4];
	int8_t		i8[4];
	uint16_t	u16[2];
	int16_t		i16[2];
	uint32_t	u32;
	int32_t		i32;
} _uWork;

/************************************************************************/
/*						    	Definitions								*/
/************************************************************************/
//------------Auxiliary------------//

#define allFlags			flags.byte

//-------------Tx & Rx-------------//

#define SIZEBUFRX			128
#define SIZEBUFTX			128

//---------------I/O---------------//

#define LEDSTATUS			PINB5

//---------Time Management---------//

#define IS10MS				0

//----------Box Activities---------//

#define BOXBUF				45
#define ONBELT				1
#define OFFBELT				0
#define ON					1
#define OFF					0

#define BLOCKNEXTSTAGE		flags.bits.bit2

/************************************************************************/
/*						  Variables and buffers							*/
/************************************************************************/
//------------Auxiliary------------//

char		strAux[64];
uint16_t	aux16				= 0;
_uFlags		flags;
uint8_t		initStatus;

//-------------Tx & Rx-------------//

uint8_t bufRXPC[SIZEBUFRX], bufTXPC[SIZEBUFTX];

_sUNERBUSHandle unerbusPC;

volatile uint8_t aux;
uint8_t connectionTimeOut;

//---------Time Management---------//

uint8_t		count100ms			= 10;
uint8_t		count1000ms			= 10;
uint8_t		timeOutBoxTask		= 0;
uint8_t		timeOutAliveUDP;

//------------HeartBeat------------//

uint32_t	hbMask				= 0x80000000;
uint32_t	heartbeat			= 0xAF000000;

//----------Box Activities---------//

_sBOX		boxInfo;
uint8_t		prueba = 0;

/************************************************************************/
/*							  Initialization							*/
/************************************************************************/

//---------Configurations----------//

void iniTimer();
void iniPorts();
void IniUSART();

//---------Time Management---------//

void every10ms();

//-----------HeartBeat-------------//

void heartbeatTask();

//------------Tx & Rx--------------//

void DecodeCMD(struct UNERBUSHandle *aBus, uint8_t iStartData);
void SendData(struct UNERBUSHandle *aBus, uint8_t id);

//----------Box Activities---------//

void boxTypeTask();

void init_Boxes();
void init_SimuCinta();
void boxID(uint8_t detectedBoxType);
void boxTask();
void PendingExitActivations();

/************************************************************************/
/*								Interruptions							*/
/************************************************************************/

ISR(USART_RX_vect)
{
	aux = UDR0;
	UNERBUS_ReceiveByte(&unerbusPC, aux);
}

ISR(TIMER1_COMPA_vect)
{								// Adds 10 ms in the timer1 comparator
	GPIOR0 |= _BV(IS10MS);							// Flag that indicates that 10 ms have passed
}

/************************************************************************/
/*								Functions								*/
/************************************************************************/

//-------------Configurations--------------//
void iniPorts()
{
	DDRB =  (1 << LEDSTATUS); // Sets PB1 (Trigger) and PB5 (Led) as OUTPUT ports
}

void iniTimer()
{
	TCCR1A = 0;										// Operation mode of Timer1: NORMAL
	OCR1A = 19999;									// Setting limit of time counter: 10 milliseconds
	TIFR1 = TIFR1;									// Clear all bits for the timer1's interruption
	TIMSK1 = (1 << OCIE1A);							// Enables interruption of Comparator A (Timer1)
	TCCR1B = (1 << WGM12) | (1 << ICNC1) | (1 << CS11);			// Input Capture Noise Canceler activated, Prescaler definition (x8)
}

void IniUSART()
{
	UCSR0A = UCSR0A;								// All bits in UCSR0A are cleared
	UCSR0A = (1 << U2X0);							// Doubles the transfer rate for asynchronous communication
	UCSR0B = (1 << RXEN0) | (1 << TXEN0) | (1 << RXCIE0);		// RX Complete Interrupt and Receiver enabled
	UCSR0C = (1 << UCSZ01) | (1 << UCSZ00);			// 8-bit character size for the Receiver and Transmitter buffers
	UBRR0 = 16;										// Sets baud rate of transmission: [UBRR0 = (16 MHz / 8*BR) - 1] (rounded)
}

//------------Time Management-------------//
void every10ms()
{
	GPIOR0 &= _BV(LEDSTATUS);						// Activation of timer: 10 cycles * 10 ms = 100 ms
	
	timeOutBoxTask--;
	if (!timeOutBoxTask) {
		timeOutBoxTask = 1;
		if (boxInfo.beltStatus) {
			boxTask();
		}
	}
	
	UNERBUS_Timeout(&unerbusPC);
	count100ms--;									// 100 milliseconds counter decrements
		
	if (!count100ms)								// If 100 ms have passed
	{
		count100ms = 10;							// Restarts 100 ms counter
		heartbeatTask();							// Control the heartbeat sequence of the system
			
		count1000ms--;
		if (!count1000ms) {							// If 1000 ms passed
			SendData(&unerbusPC, GETBELTINFO);
			count1000ms = 10;
		}

		if(connectionTimeOut)
			connectionTimeOut--;

		if(timeOutAliveUDP)
			timeOutAliveUDP--;
	}
}

//--------------HeartBeat----------------//
void heartbeatTask()
{
	if (heartbeat & hbMask)
		PORTB |= (1 << LEDSTATUS);					// Turn on LED
	else
		PORTB &= ~_BV(LEDSTATUS);					// Turn off LED
	
	hbMask >>= 1;									// Displace hbMask one place to the right
	if (!hbMask)
		hbMask = 0x80000000;						// If there's a 0 in that place, changes the actual positions to compare the right way
}

//-------------Communications-------------//

void DecodeCMD(struct UNERBUSHandle *aBus, uint8_t iStartData){
	_uWork w;
	uint8_t length = 0;
	uint8_t id;
	
	id = UNERBUS_GetUInt8(aBus);

	switch(id){
		case GETALIVE:
			if (UNERBUS_GetUInt8(aBus) == ACK) {
				connectionTimeOut = 50;
			}
			break;
		case GETBELTINFO:
			boxInfo.v = UNERBUS_GetUInt8(aBus);
			
			boxInfo.boxType0 = UNERBUS_GetUInt8(aBus);
			w.u8[0] = UNERBUS_GetUInt8(aBus);
			w.u8[1] = UNERBUS_GetUInt8(aBus);
			boxInfo.cmOut0 = w.u16[0]*10;
			
			boxInfo.boxType1 = UNERBUS_GetUInt8(aBus);
			w.u8[0] = UNERBUS_GetUInt8(aBus);
			w.u8[1] = UNERBUS_GetUInt8(aBus);
			boxInfo.cmOut1 = w.u16[0]*10;
			
			boxInfo.boxType2 = UNERBUS_GetUInt8(aBus);
			w.u8[0] = UNERBUS_GetUInt8(aBus);
			w.u8[1] = UNERBUS_GetUInt8(aBus);
			boxInfo.cmOut2 = w.u16[0]*10;
			break;
		case STOPBELT:
			break;
		case BOXKICK:
			break;
		case BELTRESET:
			break;
		case SPEEDCHANGE:
			boxInfo.v = UNERBUS_GetUInt8(aBus);
			break;
		case NEWBOX:
			boxInfo.beltStatus = ON;
			boxID(UNERBUS_GetUInt8(aBus));
			break;
	}

	if(length){
		UNERBUS_Send(aBus, id, length);
	}
}

void SendData(struct UNERBUSHandle *aBus, uint8_t id){
	uint8_t aux8;
	uint8_t length = 0;

	switch(id){
		case GETALIVE:
			length = 1;
			break;
		case GETBELTINFO:
			length = 1;
			break;
		case STOPBELT:
			length = 1;
			break;
		case BOXKICK:
			UNERBUS_WriteByte(aBus, boxInfo.openExitType); //boxInfo.openExitType
			length = 2;
			break;
		case BELTRESET:
			length = 1;
			break;
		case SPEEDCHANGE:
			UNERBUS_WriteByte(aBus, boxInfo.v);
			length = 2;
			break;
	}

	if(length){
		UNERBUS_Send(aBus, id, length);
	}
}

//-------------Box Activities-------------//
void init_Boxes(){
	boxInfo.iLastBox = 0;
	boxInfo.iOnBelt = 0;
	boxInfo.v = 10;
	boxInfo.beltStatus = OFF;
	boxInfo.boxType0 = 5;
	boxInfo.boxType1 = 8;
	boxInfo.boxType2 = 11;
	boxInfo.cmOut0 = 2000;
	boxInfo.cmOut1 = 4000;
	boxInfo.cmOut2 = 6000;
	boxInfo.openExitType = 5;
	
	for(uint8_t i=0; i<BOXBUF; i++) {
		boxInfo.ActualExitTimes[i] = 0;
		boxInfo.ExitTimeObjectives[i] = 0;
		boxInfo.BoxesStatus[i] = OFFBELT;
		boxInfo.boxesDetectedTypes[i] = 5;
	}
}

void boxID(uint8_t detectedBoxType){	
	uint32_t tempCalculation = 0;
	
	if (detectedBoxType == boxInfo.boxType0) {
		tempCalculation = (uint32_t)boxInfo.cmOut0 * 10;
		boxInfo.ExitTimeObjectives[boxInfo.iLastBox] = (uint32_t)(tempCalculation / boxInfo.v);  // tendria que ser (cmOut/v)*10 pero es mejor multiplicar antes  (boxInfo.cmOut0*10)/boxInfo.v  (boxInfo.cmOut0/boxInfo.v)*10
		boxInfo.boxesDetectedTypes[boxInfo.iLastBox] = boxInfo.boxType0;
	} else if (detectedBoxType == boxInfo.boxType1) {
		tempCalculation = (uint32_t)boxInfo.cmOut1 * 10;
		boxInfo.ExitTimeObjectives[boxInfo.iLastBox] = (uint32_t)(tempCalculation / boxInfo.v);
		boxInfo.boxesDetectedTypes[boxInfo.iLastBox] = boxInfo.boxType1;
	} else if (detectedBoxType == boxInfo.boxType2) {
		tempCalculation = (uint32_t)boxInfo.cmOut2 * 10;
		boxInfo.ExitTimeObjectives[boxInfo.iLastBox] = (uint32_t)(tempCalculation / boxInfo.v);
		boxInfo.boxesDetectedTypes[boxInfo.iLastBox] = boxInfo.boxType2;
	} else
		return;

	boxInfo.ActualExitTimes[boxInfo.iLastBox] = 0;
	boxInfo.BoxesStatus[boxInfo.iLastBox++] = ONBELT;
	
	if (boxInfo.iLastBox > BOXBUF-1)
		boxInfo.iLastBox = 0;
}

void boxTask(){
	uint8_t i = boxInfo.iOnBelt;
	while (i != boxInfo.iLastBox) {
		if (boxInfo.ActualExitTimes[i] < boxInfo.ExitTimeObjectives[i]) {
			boxInfo.ActualExitTimes[i] += 10;
		} else {
			if (boxInfo.BoxesStatus[i] == ONBELT) {
				boxInfo.BoxesStatus[i] = OFFBELT;
				if (boxInfo.boxesDetectedTypes[i] == boxInfo.boxType0) {
					boxInfo.openExitType = boxInfo.boxType0;
				} else if (boxInfo.boxesDetectedTypes[i] == boxInfo.boxType1) {
					boxInfo.openExitType = boxInfo.boxType1;
				} else if (boxInfo.boxesDetectedTypes[i] == boxInfo.boxType2) {
					boxInfo.openExitType = boxInfo.boxType2;
				}
				SendData(&unerbusPC, BOXKICK);
			}
			if (i==boxInfo.iOnBelt) {
				boxInfo.iOnBelt++;
				if (boxInfo.iOnBelt > BOXBUF-1)
					boxInfo.iOnBelt = 0;
			}
		}
		i++;
		
		if (i > BOXBUF-1)
			i = 0;
	}
}

//-------------Main function--------------//
int main(void)
{
	cli();
	allFlags = 0;								// Initializes flags
	iniPorts();										// Initializes ports
	iniTimer();										// Initializes timer1
	IniUSART();										// Initializes USART
	
	init_Boxes();									// Iniializes BOXES
	
	unerbusPC.MyDataReady = DecodeCMD;
	unerbusPC.WriteUSARTByte = NULL;
	unerbusPC.rx.buf = bufRXPC;
	unerbusPC.rx.maxIndexRingBuf = (SIZEBUFRX - 1);
	unerbusPC.tx.buf = bufTXPC;
	unerbusPC.tx.maxIndexRingBuf = (SIZEBUFTX - 1);
	
	UNERBUS_Init(&unerbusPC);
	
	timeOutAliveUDP = 10;
	initStatus = 0;
	connectionTimeOut = 0;
	
	sei();
	
	while (1)
	{
		if (GPIOR0 & _BV(IS10MS))					// If 10 ms have passed
			every10ms();
		
		if(!timeOutAliveUDP){
			timeOutAliveUDP = 10;
			SendData(&unerbusPC, GETBELTINFO);
		}
		
		if(unerbusPC.tx.iRead != unerbusPC.tx.iWrite){
			if(UCSR0A & _BV(UDRE0)){
				UDR0 = unerbusPC.tx.buf[unerbusPC.tx.iRead++];
				unerbusPC.tx.iRead &= unerbusPC.tx.maxIndexRingBuf;
			}
		}
			
		UNERBUS_Task(&unerbusPC);
	}
}